accu_val = 0;
mean_2=[];mean_5=[];mean_10=[];mean_16=[];mean_20=[];
CovarMatrix_2=[];CovarMatrix_5=[];CovarMatrix_10=[];CovarMatrix_16=[];CovarMatrix_20=[];
imgset2_test=[];imgset5_test=[];imgset10_test=[];imgset16_test=[];imgset20_test=[];
prior_prob_2=0; prior_prob_5=0; prior_prob_10=0; prior_prob_16=0; prior_prob_20=0;
while(accu_val < 0.4)
    All_img_data = random();
    [prior_prob_2,imgset2_train,imgset2_test, imgset2_val] = All_img_data.imgset2 ;
    [prior_prob_5,imgset5_train,imgset5_test, imgset5_val] = All_img_data.imgset5 ;
    [prior_prob_10,imgset10_train,imgset10_test, imgset10_val] = All_img_data.imgset10 ;
    [prior_prob_16,imgset16_train,imgset16_test, imgset16_val] = All_img_data.imgset16 ;
    [prior_prob_20,imgset20_train,imgset20_test, imgset20_val] = All_img_data.imgset20 ;
     
    mean_2 = mean(imgset2_train);
    CovarMatrix_2 = get_CovarMatrix(imgset2_train);
    mean_5 = mean(imgset5_train);
    CovarMatrix_5 = get_CovarMatrix(imgset5_train);
    mean_10 = mean(imgset10_train);
    CovarMatrix_10 = get_CovarMatrix(imgset10_train);
    mean_16 = mean(imgset16_train);
    CovarMatrix_16 = get_CovarMatrix(imgset16_train);
    mean_20 = mean(imgset20_train);
    CovarMatrix_20 = get_CovarMatrix(imgset20_train);

    confusion_matrix = zeros(5);
    total_hits_test = 0;

    field1 = 'mean';    field2 = 'covariance';  field3 = 'probability';
    values1 = {mean_2;mean_5;mean_10;mean_16;mean_20};
    values2 = {CovarMatrix_2;CovarMatrix_5;CovarMatrix_10;CovarMatrix_16;CovarMatrix_20};
    values3 = [prior_prob_2 prior_prob_5 prior_prob_10 prior_prob_16 prior_prob_20];
    Params = struct(field1,values1,field2,values2,field3,values3);

    confusion_matrix(1,:) = assign_class(imgset2_val,Params);
    total_hits_test = total_hits_test + sum(confusion_matrix(1,:));
    confusion_matrix(2,:) = assign_class(imgset5_val,Params);
    total_hits_test = total_hits_test + sum(confusion_matrix(2,:));
    confusion_matrix(3,:) = assign_class(imgset10_val,Params);
    total_hits_test = total_hits_test + sum(confusion_matrix(3,:));
    confusion_matrix(4,:) = assign_class(imgset16_val,Params);
    total_hits_test = total_hits_test + sum(confusion_matrix(4,:));
    confusion_matrix(5,:) = assign_class(imgset20_val,Params);
    total_hits_test = total_hits_test + sum(confusion_matrix(5,:));

    total_correct_hits_test = trace(confusion_matrix);
    accu_val = total_correct_hits_test/total_hits_test;
    %confusion_matrix
    %fprintf('Classification Accuracy on val data: %f\n',accu_val);
end

confusion_matrix
fprintf('Classification Accuracy on val data: %f\n',accu_val);

confusion_matrix = zeros(5);
total_hits_test = 0;

field1 = 'mean';    field2 = 'covariance';  field3 = 'probability';
values1 = {mean_2;mean_5;mean_10;mean_16;mean_20};
values2 = {CovarMatrix_2;CovarMatrix_5;CovarMatrix_10;CovarMatrix_16;CovarMatrix_20};
values3 = [prior_prob_2 prior_prob_5 prior_prob_10 prior_prob_16 prior_prob_20];
Params = struct(field1,values1,field2,values2,field3,values3);

confusion_matrix(1,:) = assign_class(imgset2_test,Params);
total_hits_test = total_hits_test + sum(confusion_matrix(1,:));
confusion_matrix(2,:) = assign_class(imgset5_test,Params);
total_hits_test = total_hits_test + sum(confusion_matrix(2,:));
confusion_matrix(3,:) = assign_class(imgset10_test,Params);
total_hits_test = total_hits_test + sum(confusion_matrix(3,:));
confusion_matrix(4,:) = assign_class(imgset16_test,Params);
total_hits_test = total_hits_test + sum(confusion_matrix(4,:));
confusion_matrix(5,:) = assign_class(imgset20_test,Params);
total_hits_test = total_hits_test + sum(confusion_matrix(5,:));

total_correct_hits_test = trace(confusion_matrix);
accuracy_test = total_correct_hits_test/total_hits_test;
confusion_matrix
fprintf('Classification Accuracy on test data: %f\n',accuracy_test);


function no_of_assignments = assign_class(imgset_test,Params)
    l_test = length(imgset_test(:,1));
    no_of_assignments = zeros(1,5);
    [mean_2,mean_5,mean_10,mean_16,mean_20] = Params.mean;
    [CovarMatrix_2,CovarMatrix_5,CovarMatrix_10,CovarMatrix_16,CovarMatrix_20] = Params.covariance;
    Probabilities = Params.probability;
    for i = 1:l_test
        disc_val = zeros(1,5);
        X = imgset_test(i,:);
        disc_val(1) = discriminant_func_B(X,mean_2,CovarMatrix_2,Probabilities(1));
        disc_val(2) = discriminant_func_B(X,mean_5,CovarMatrix_5,Probabilities(2));
        disc_val(3) = discriminant_func_B(X,mean_10,CovarMatrix_10,Probabilities(3));
        disc_val(4) = discriminant_func_B(X,mean_16,CovarMatrix_16,Probabilities(4));
        disc_val(5) = discriminant_func_B(X,mean_20,CovarMatrix_20,Probabilities(5));
        
        [~,class_label] = max(disc_val);
        no_of_assignments(class_label) = no_of_assignments(class_label) + 1;
        %fprintf('Assigning class %.0f to (%f,%f)\n',class_label,X(1),X(2));
    end
end        

function val = discriminant_func_B(x,Mean,CoVarMatrix,Prob)
   %Bayes || diff C 
   %val = ((-1/2)*log(det(CoVarMatrix)))+((-1/2)*((x-Mean)*(inv(CoVarMatrix))*(transpose(x-Mean)))) + log(Prob);	
   val = log(mvnpdf(x,Mean,CoVarMatrix))+ log(Prob);
end

function covarmatrix = get_CovarMatrix(arr) 
    Var_train = var(arr);
    dimension = length(arr(1,:));
    covarmatrix = zeros(dimension);
    for i = 1:dimension
        covarmatrix(i,i) = Var_train(i);
    end
    %covarmatrix = covarmatrix + eye(48)*0.000000001;
    %disp(det(covarmatrix));
end